public class Main
{
  public static void main (String[]args)
  {
    char a = 'a';
    char b = 'e';
    if (a < b)
      {
	System.out.print(a);
    System.out.print(b);

      }
    else
      {
	System.out.print(b);
	System.out.print(a);
      }
  }
}
