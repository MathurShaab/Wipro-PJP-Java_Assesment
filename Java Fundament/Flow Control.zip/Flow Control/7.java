public class Main
{
  public static void main (String[]args)
  {
     char a ='A';
     if(Character.isUpperCase(a))
        {
            System.out.println(Character.toLowerCase(a));
        }
        else{
            System.out.println(Character.toUpperCase(a));
        }
  }
}
