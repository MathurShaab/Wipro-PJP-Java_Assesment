public class Main
{
  public static void main (String[]args)
  {
      for(int i=24;i<57;i=i+1)
        {
         if(i%2==0)
         {
             System.out.println(i);
         }
        }
  }
}
