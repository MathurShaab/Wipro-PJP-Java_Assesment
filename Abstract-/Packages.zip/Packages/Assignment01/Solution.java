package test;

public class Solution {

	public static void main(String[] args) {
		
		Foundation foundation = new Foundation();
							
		foundation.var2 = 2;					
		foundation.var3 = 3;					
		foundation.var4 = 4;					
		
			
		System.out.println(foundation.var2);
		System.out.println(foundation.var3);
		System.out.println(foundation.var4);
	}

}